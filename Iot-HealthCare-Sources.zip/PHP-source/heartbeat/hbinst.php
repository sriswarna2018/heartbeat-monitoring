<html>
<head>
<meta http-equiv="refresh" content="5" />
</head>
<body style="background-image:url(images/h7.png)">
<?php // Get TD String for style input
function get_td_string($height,$width,$b_color, $f_font,$f_color,$f_size,$f_fnt_wt, $v_align, $text_align, $col_span, $row_span, $content)
{
if ($col_span=='0') $col_span='';
if ($row_span=='0') $row_span='';
$td_str = <<<STR1
<td align="$text_align" style="background-color:$b_color; width:$width; height:$height;"  colspan="$col_span" rowspan="$row_span">
<font face="$f_font" color="$f_color"  style="font-weight:$f_fnt_wt; font-size:$f_size; " >$content </font> </td> 
STR1;
return $td_str;	
}

?>
<?php // style text
function Style_Text($b_color, $f_font,$f_color,$f_size,$f_fnt_wt, $v_align, $text_align, $content)
{
$td_str = <<<STR1
<a align='$text_align' style='background-color:$b_color;'>
<font face='$f_font' color='$f_color'  style='font-weight:$f_fnt_wt;font-size:$f_size;'>$content</font></a>
STR1;
return $td_str;	
}
?>
<?php
$servername = "192.168.15.27";
$username = "swarna";
$password = "swarna";
$dbname = "heartbeat";

// Create connection
$conn = new mysqli($servername, $username, NULL, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT hbi_val FROM hbinstant";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		?>
		<div align="center">
		<?php
		echo Style_Text("","algerian","blue","30px","bold","middle","center", "Heart Beat   :");
		$color1="green";
		if ($row["hbi_val"]<60 || $row["hbi_val"]>100) $color1="red";
		echo Style_Text("","algerian",$color1,"30px","bold","middle","center", $row["hbi_val"]);
		?>
		
		
		<?php
        
    }
} else {
    echo "0 results";
}
$conn->close();
?>
</body>
</html>