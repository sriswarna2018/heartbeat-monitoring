<?php
$servername = "192.168.15.27";
$username = "swarna";
$password = "swarna";
$dbname = "heartbeat";

// Create connection
$conn = new mysqli($servername, $username, NULL, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

?>
<body style="background-image:url(images/h7.png)">
<center>
<div>
<form method="POST" action="hblog.php">
<input type="text" placeholder="dd-mm-yyyy" name="start_date">
<input type="text" placeholder="dd-mm-yyyy" name="end_date">
<button type="submit"> submit </button>
</form>
</div>

<?php // Get TD String for style input
function get_td_string($height,$width,$b_color, $f_font,$f_color,$f_size,$f_fnt_wt, $v_align, $text_align, $col_span, $row_span, $content)
{
if ($col_span=='0') $col_span='';
if ($row_span=='0') $row_span='';
$td_str = <<<STR1
<td align="$text_align" style="background-color:$b_color; width:$width; height:$height;"  colspan="$col_span" rowspan="$row_span">
<font face="$f_font" color="$f_color"  style="font-weight:$f_fnt_wt; font-size:$f_size; " >$content </font> </td> 
STR1;
return $td_str;	
}

?>
<?php // style text
function Style_Text($b_color, $f_font,$f_color,$f_size,$f_fnt_wt, $v_align, $text_align, $content)
{
$td_str = <<<STR1
<a align='$text_align' style='background-color:$b_color;'>
<font face='$f_font' color='$f_color'  style='font-weight:$f_fnt_wt;font-size:$f_size;'>$content</font></a>
STR1;
return $td_str;	
}
?>
<?php
isset($_POST["start_date"]) ? $start_date=$_POST["start_date"] : $start_date=date("d-m-Y");
isset($_POST["end_date"]) ? $end_date=$_POST["end_date"] : $end_date=date("d-m-Y");
//echo $start_date."<br>";
$start_date=DateTime::createFromFormat('d-m-Y',$start_date )->format('Y-m-d');
$end_date=DateTime::createFromFormat('d-m-Y',$end_date )->format('Y-m-d');

//echo $start_date."<br>";
//echo $end_date."<br>";
$sql = "SELECT DATE_FORMAT(hb_date,'%d-%b-%Y %H:%i') dt, hb_val FROM heartbeat where date(hb_date) between '".$start_date."' and '".$end_date."' order by hb_date desc";
//echo $sql;
$result = $conn->query($sql);
if ($result->num_rows > 0)
	{
		echo "<table border=1>";
    // output data of each row
    while($row = $result->fetch_assoc())
		{
         //echo "<b><font color='blue'> date:</font>;</b>" . $row["hb_date"]. " <b><font color='violet'>- value:</font>;</b> " . $row["hb_val"]. "<br>";
		 ?>
		  <tr>
		  <td><?php echo Style_Text("","algerian","purple","15px","bold","middle","center", $row["dt"]); ?></td>
		  <td><?php echo Style_Text("","algerian"," brown","15px","bold","middle","center", $row["hb_val"]);?></td>
		  </tr>
		 <?php
        }
		echo "</table>";
    }

else 
{
    echo "0 results";
}
$conn->close();
?>
</center>
</body>