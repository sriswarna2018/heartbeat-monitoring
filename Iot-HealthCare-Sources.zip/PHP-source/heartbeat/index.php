<html>

<head>
<title> Heart Beat Monitoring </title>
</head>
<body style="background-image:url(images/h4.png)">
<?php // Get TD String for style input
function get_td_string($height,$width,$b_color, $f_font,$f_color,$f_size,$f_fnt_wt, $v_align, $text_align, $col_span, $row_span, $content)
{
if ($col_span=='0') $col_span='';
if ($row_span=='0') $row_span='';
$td_str = <<<STR1
<td align="$text_align" style="background-color:$b_color; width:$width; height:$height;"  colspan="$col_span" rowspan="$row_span">
<font face="$f_font" color="$f_color"  style="font-weight:$f_fnt_wt; font-size:$f_size; " >$content </font> </td> 
STR1;
return $td_str;	
}

?>
<?php // style text
function Style_Text($b_color, $f_font,$f_color,$f_size,$f_fnt_wt, $v_align, $text_align, $content)
{
$td_str = <<<STR1
<a align='$text_align' style='background-color:$b_color;'>
<font face='$f_font' color='$f_color'  style='font-weight:$f_fnt_wt;font-size:$f_size;'>$content</font></a>
STR1;
return $td_str;	
}
?>
<center>
<div>
<?php
echo Style_Text("","algerian","violet","40px","bold","middle","center", "Heart Beat Monitoring Project");
?>
</div>
<iframe src="hbinst.php" style="background-color:white;margin-top:50px;margin-left:0px;min-width:400px;height:80px;"> </iframe>
<br>
<iframe src="hblog.php" style="background-color:white;margin-top:10px;margin-left:0px;min-width:600px;height:200px;"> </iframe>
</center>
</body>
</html>