
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include <winsock2.h>
#include <mysql.h>
#include <dos.h>

using namespace std;

HANDLE  serial_ini()
{
// Open serial port
HANDLE serialHandle;
serialHandle = CreateFile("\\\\.\\COM7", GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
// Do some basic settings
DCB serialParams = { 0 };
serialParams.DCBlength = sizeof(serialParams);
GetCommState(serialHandle, &serialParams);
serialParams.BaudRate = CBR_9600;
serialParams.ByteSize = 8;
serialParams.StopBits = ONESTOPBIT;
serialParams.Parity = NOPARITY;
SetCommState(serialHandle, &serialParams);
// Set timeouts
COMMTIMEOUTS timeout = { 150 };
timeout.ReadIntervalTimeout = 150;
timeout.ReadTotalTimeoutConstant = 150;
timeout.ReadTotalTimeoutMultiplier = 50;
timeout.WriteTotalTimeoutConstant = 50;
timeout.WriteTotalTimeoutMultiplier =10;
SetCommTimeouts(serialHandle, &timeout);
return serialHandle;
}

int main()
{
printf("\nWelcome to Heart Beat Monitoring Project");
 MYSQL *conn;
 MYSQL_RES *res;
 MYSQL_ROW row;
 char *server = "192.168.15.27";
 char *user = "swarna";
 char *password = "swarna";
 char *database = "heartbeat";
int key_hit=0;
string head_str="";
string bpm_str="";
string bpm_ret_str="";
string qry_str="";
unsigned int track_time=0;


printf("\nInitialising Mysql........");
conn = mysql_init(NULL);

 printf("\nConnecting Mysql........");
 if (!mysql_real_connect(conn, server, user, NULL, database, 3306, NULL, 0)) {
      printf("%s\n", mysql_error(conn));
      exit(1);
   }

printf("\nInitialising COM Port.........");
HANDLE serialHandle=serial_ini();
 if (serialHandle==INVALID_HANDLE_VALUE)
{
	printf("\nError opening Serial Port ");
	mysql_close(conn);
	exit(1);
}
printf("\nMySQL Connected");
printf("\nCom Port Open = Success");
printf("\nServer Running.... ");
printf("\nPress ESC key to Stop Server ");
while(key_hit!=27)
 {
	DWORD bytesWritten;
	BOOL readSuccess;
	unsigned char TempChar;
	char SerialBuffer[256];
	
	WriteFile(serialHandle,"1",1,&bytesWritten,NULL);
	char buff2[20]={1,2,3};
	DWORD nRead=1;
	Sleep(500);
	readSuccess=ReadFile(serialHandle,buff2 ,10, &nRead, NULL);
	bpm_ret_str=buff2;
	head_str=bpm_ret_str.substr(0,3);
	bpm_str=bpm_ret_str.substr(3,bpm_ret_str.length()-1);
	track_time++;
	
	if (head_str!="49,") bpm_str="error";
	if((track_time%60)==0 && bpm_str!="error")
	{
	
	qry_str="INSERT INTO heartbeat VALUES(NOW(),'"+bpm_str+"') ";
    if (mysql_query(conn, qry_str.c_str())) 
	{
      printf( "%s\n", mysql_error(conn));
     
    }
    if (mysql_query(conn, "commit")) 
	{
      printf( "%s\n", mysql_error(conn));
   
    }
	
    }
    if((track_time%5)==0)
	{
    qry_str="UPDATE hbinstant SET hbi_val='"+bpm_str+"' WHERE hbi_ref=1 ";
    if (mysql_query(conn, qry_str.c_str())) 
	{
      printf( "%s\n", mysql_error(conn));
      
    }
    if (mysql_query(conn, "commit")) 
	{
      printf( "%s\n", mysql_error(conn));
  
    }
    }

	
if (kbhit())
{
    key_hit = getch();

}
}
mysql_close(conn);
CloseHandle(serialHandle);
printf("\nServer Stopped..... (Press any key to exit) ");
getch();
}


